# Superb Mirror — geliştirme prototipi 0.3-dev

Bu Android Studio kaynak projesi, Redmi Note 15 Pro 5G'den yerel Wi‑Fi üzerinden görüntü göndermek ve gelecekte harici bir donanım köprüsünden gelen dokunma/kaydırma komutlarını telefona iletmek için hazırlanmıştır.

## 0.3-dev sürümündeki değişiklikler
- Ekran görüntüsü JPEG'e dönüştürme işlemi ana iş parçacığından ayrıldı.
- Dokunma köprüsü artık GET sorgu parametresi yerine JSON gövdeli `POST /control` kullanıyor.
- `tap` ve `swipe` komutları eklendi.
- Kontrol anahtarı URL yerine `X-SuperbMirror-Key` başlığında doğrulanıyor; karşılaştırma sabit zamanlı yapılıyor.
- İstek gövdesi boyutu ve komut sıklığı sınırlandı.
- Sürüm numarası 0.3-dev olarak güncellendi.

## Mimari

```text
Redmi Note 15 Pro 5G
  ├─ Android MediaProjection izni
  ├─ JPEG/MJPEG ekran akışı ── Wi‑Fi ──> araçtaki HDMI görüntü alıcısı / tarayıcı
  └─ POST /control <── Wi‑Fi <── doğrulanması gereken dokunmatik geri dönüş köprüsü
       └─ AccessibilityService.dispatchGesture()
```

## Çok önemli: orijinal Skoda dokunmatiği henüz çözümlenmedi

Bu uygulama tek başına Skoda'nın orijinal ekranından dokunma olaylarını alamaz. NavLinkz HDV-MIB92 kılavuzu, uyumlu 9,2 inç Columbus sistemlerde HDMI video kaynağını gösterebildiğini belirtir; ancak aynı kılavuz arayüzün yalnızca video sinyali eklediğini ve HDMI kaynağı için dokunmatik geri dönüş sağlamadığını gösterir. Bu nedenle HDMI video arayüzü, iki yönlü kontrol çözümü değildir.

Orijinal ekrana ikinci bir dokunmatik katman takılmayacaktır. İleride araştırılacak olası yol, aracın mevcut dokunmatik denetleyicisi ile harici bir köprü arasındaki uyumluluğun, tam ünite modeli ve kablo/topoloji doğrulandıktan sonra incelenmesidir. Dokunmatik panel/I²C/LVDS kablolarına rastgele bağlantı yapılmamalıdır.

## Redmi Note 15 Pro 5G

Telefonun USB-C bağlantısı DisplayPort Alt Mode görüntü çıkışını desteklemediğinden kablolu USB-C–HDMI yöntemi hedeflenmiyor. Görüntü aktarımı Wi‑Fi üzerinden tasarlanmıştır.

## Android izinleri ve güvenlik

1. Uygulama kullanıcıdan her ekran yakalama oturumu için MediaProjection onayı ister.
2. Dokunma/kaydırma göndermek için kullanıcı, Android Erişilebilirlik ayarlarından Superb Mirror hizmetini kendisi etkinleştirmelidir.
3. Kontrol API'si yalnızca yerel ağ için tasarlanmıştır. Bu geliştirme sürümünde TLS, sertifika doğrulama, cihaz bazlı kalıcı eşleştirme ve internet üzerinden güvenli erişim yoktur. Güvenilmeyen Wi‑Fi ağlarında kullanmayın; kontrol anahtarını paylaşmayın.
4. Uygulama yalnızca kullanıcı tarafından başlatılan izinli oturumlarda ekran yakalar. DRM, bankacılık ve güvenli ekranlar karartılabilir veya yakalamayı engelleyebilir.

## Yerel kontrol API'si (test amaçlı)

`POST http://TELEFON_IP:8080/control`

Başlıklar:

```http
Content-Type: application/json
X-SuperbMirror-Key: UYGULAMADAKI_KONTROL_ANAHTARI
```

Dokunma gövdesi:

```json
{"action":"tap","x":0.5,"y":0.5,"holdMs":70}
```

Kaydırma gövdesi:

```json
{"action":"swipe","x1":0.8,"y1":0.5,"x2":0.2,"y2":0.5,"durationMs":350}
```

`x` ve `y` değerleri 0–1 arasında normalize edilmiş ekran koordinatlarıdır. Bu API, araç ekranı dokunmatik olaylarını kendiliğinden almaz; yalnızca uyumlu bir harici köprü komut gönderirse telefonda Android erişilebilirlik hareketi üretir.

## Derleme ve test durumu

Bu kaynak güncellemesi Android Studio projesi olarak hazırlanmıştır. Bu çalışma ortamında Android SDK/Gradle derleme zinciri bulunmadığı için APK derlemesi ve gerçek cihaz testi yapılmamıştır. Dolayısıyla bu dosya **çalışan APK olarak sunulmamaktadır**.

Android Studio'da JDK 17 ve Android SDK 35 ile açıp Gradle senkronizasyonu yapın. Ardından `Build > Build Bundle(s) / APK(s) > Build APK(s)` ile derleyin. Derleme başarılı olsa bile gerçek araç dokunmatiğiyle kontrol ancak donanım köprüsü doğrulanıp test edildikten sonra mümkün olabilir.

## Güvenli test

Bütün kurulum ve testler araç park hâlindeyken yapılmalıdır. Sürüş sırasında video izlemeyin veya telefon kontrol etmeyin.

## Sadece telefonla bulutta APK derleme

Bu projeye `.github/workflows/android-apk.yml` iş akışı eklendi. Kaynak dosyaları GitHub deposuna yüklendikten sonra **Actions > Build SuperbMirror APK > Run workflow** adımlarıyla derleme başlatılabilir. İşlem başarılı olursa ilgili çalışmanın **Artifacts** bölümünden `SuperbMirror-debug-apk` indirilir. Bu yöntem Android Studio gerektirmez; derleme GitHub sunucularında yapılır.

Not: Bu iş akışı henüz gerçek bir derleme ile doğrulanmadı. Derleme başarılı olsa bile APK'nın araç ekranındaki dokunmatik geri dönüşünü sağladığı anlamına gelmez; araçta ayrıca test edilmelidir.
