package com.superbmirror.app

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import java.util.UUID
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 4101
    private val prefs by lazy { getSharedPreferences("superb_mirror", MODE_PRIVATE) }
    private val controlKey: String by lazy {
        prefs.getString("control_key", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("control_key", it).apply() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "SUPERB MIRROR"
            textSize = 26f
        })
        layout.addView(TextView(this).apply {
            text = "Geliştirme 0.3 • Kablosuz görüntü + dokunma/kaydırma köprüsü"
            textSize = 15f
        })
        layout.addView(Button(this).apply {
            text = "Dokunmatik kontrol iznini aç"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(TextView(this).apply {
            text = "Kontrol anahtarı (güvenli yerel köprü için):\n$controlKey"
            textSize = 12f
        })
        layout.addView(Button(this).apply {
            text = "TELEFONDA: Ekran paylaşımını başlat"
            setOnClickListener { requestScreenCapture() }
        })
        layout.addView(Button(this).apply {
            text = "ARAÇ EKRANINDA: Görüntüyü aç"
            setOnClickListener { showReceiver() }
        })
        layout.addView(TextView(this).apply {
            text = "Bağlantı: Telefon ve alıcı aynı Wi‑Fi ağında olmalı. Araçtan gelen kontrol köprüsü için POST /control (JSON) kullanılır. Orijinal Skoda dokunmatiğinin bu ağa bağlanması için donanım henüz doğrulanmadı."
            textSize = 14f
        })
        setContentView(layout)
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility in this prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ScreenStreamService::class.java).apply {
                putExtra(ScreenStreamService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenStreamService.EXTRA_DATA, data)
                putExtra(ScreenStreamService.EXTRA_CONTROL_KEY, controlKey)
            }
            startForegroundService(service)
            Toast.makeText(this, "Ekran paylaşımı başlatılıyor. Telefonun IP adresini araç ekranına girin.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showReceiver() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 16, 12, 12)
        }
        val ip = EditText(this).apply {
            hint = "Telefonun IP adresi (örn. 192.168.43.1)"
            setSingleLine(true)
        }
        layout.addView(ip)
        layout.addView(Button(this).apply {
            text = "Bağlan"
            setOnClickListener {
                val address = ip.text.toString().trim()
                if (address.isBlank()) {
                    Toast.makeText(this@MainActivity, "Önce telefonun IP adresini girin.", Toast.LENGTH_SHORT).show()
                } else {
                    val url = "http://$address:8080/"
                    val web = WebView(this@MainActivity).apply {
                        settings.javaScriptEnabled = false
                        settings.domStorageEnabled = false
                        webViewClient = WebViewClient()
                        loadUrl(url)
                    }
                    layout.removeAllViews()
                    layout.addView(web, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
                    ))
                }
            }
        })
        layout.addView(TextView(this).apply {
            text = "Bu alıcı ekranı test içindir. Dokunma API’si hazırdır; orijinal Skoda ekranından bu API’ye komut taşıyan uyumlu donanım henüz doğrulanmadı."
            textSize = 14f
        })
        setContentView(layout)
    }
}
