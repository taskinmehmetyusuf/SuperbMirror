package com.superbmirror.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class ScreenStreamService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_CONTROL_KEY = "control_key"
        private const val CHANNEL_ID = "superb_mirror_stream"
        private const val PORT = 8080
        private const val MAX_BODY = 2048
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var server: ServerSocket? = null
    private var captureThread: HandlerThread? = null
    private val running = AtomicBoolean(false)
    private val latestJpeg = AtomicReference<ByteArray?>(null)
    private val lastControlAt = AtomicLong(0L)
    private var controlKey: String = ""

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(7, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running.get()) return START_NOT_STICKY
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
        controlKey = intent.getStringExtra(EXTRA_CONTROL_KEY).orEmpty()
        if (data == null || controlKey.length < 24) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            startCapture()
            startHttpServer()
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        captureThread = HandlerThread("SuperbMirrorCapture").also { it.start() }
        val handler = Handler(captureThread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) latestJpeg.set(imageToJpeg(image))
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, handler)
        virtualDisplay = projection?.createVirtualDisplay(
            "SuperbMirrorCapture", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
    }

    private fun imageToJpeg(image: Image): ByteArray? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val paddedWidth = image.width + (rowStride - pixelStride * image.width) / pixelStride
        val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        full.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
        val output = ByteArrayOutputStream()
        cropped.compress(Bitmap.CompressFormat.JPEG, 65, output)
        full.recycle()
        cropped.recycle()
        return output.toByteArray()
    }

    private fun startHttpServer() {
        if (!running.compareAndSet(false, true)) return
        Thread({
            try {
                server = ServerSocket(PORT)
                while (running.get()) {
                    val client = server?.accept() ?: break
                    Thread({ handleClient(client) }, "SuperbMirrorClient").start()
                }
            } catch (_: Exception) {
                // Expected when the service closes its listening socket.
            }
        }, "SuperbMirrorHTTP").start()
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 5000
                val input = BufferedInputStream(client.getInputStream())
                val requestLine = readAsciiLine(input, 2048) ?: return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return
                val method = parts[0]
                val path = parts[1]
                val headers = mutableMapOf<String, String>()
                while (true) {
                    val line = readAsciiLine(input, 4096) ?: return
                    if (line.isEmpty()) break
                    val colon = line.indexOf(':')
                    if (colon > 0) headers[line.substring(0, colon).trim().lowercase()] = line.substring(colon + 1).trim()
                }
                val out = client.getOutputStream()
                when {
                    method == "POST" && path == "/control" -> {
                        val supplied = headers["x-superbmirror-key"].orEmpty().toByteArray(Charsets.UTF_8)
                        val expected = controlKey.toByteArray(Charsets.UTF_8)
                        if (!MessageDigest.isEqual(expected, supplied)) {
                            respond(out, "403 Forbidden", "Kimlik doğrulama başarısız")
                            return
                        }
                        val length = headers["content-length"]?.toIntOrNull() ?: -1
                        if (length !in 1..MAX_BODY) {
                            respond(out, "413 Payload Too Large", "Geçersiz istek boyutu")
                            return
                        }
                        val body = ByteArray(length)
                        var offset = 0
                        while (offset < length) {
                            val count = input.read(body, offset, length - offset)
                            if (count < 0) return
                            offset += count
                        }
                        val now = System.currentTimeMillis()
                        if (now - lastControlAt.get() < 35L) {
                            respond(out, "429 Too Many Requests", "Komut hızı sınırı")
                            return
                        }
                        lastControlAt.set(now)
                        val json = JSONObject(String(body, Charsets.UTF_8))
                        val action = json.optString("action")
                        val accepted = when (action) {
                            "tap" -> TouchAccessibilityService.tap(
                                json.optDouble("x", -1.0).toFloat(),
                                json.optDouble("y", -1.0).toFloat(),
                                json.optLong("holdMs", 70L)
                            )
                            "swipe" -> TouchAccessibilityService.swipe(
                                json.optDouble("x1", -1.0).toFloat(), json.optDouble("y1", -1.0).toFloat(),
                                json.optDouble("x2", -1.0).toFloat(), json.optDouble("y2", -1.0).toFloat(),
                                json.optLong("durationMs", 350L)
                            )
                            else -> false
                        }
                        respond(out, if (accepted) "200 OK" else "409 Conflict", if (accepted) "Komut gönderildi" else "Erişilebilirlik kapalı veya komut geçersiz")
                    }
                    method == "GET" && path == "/stream.mjpg" -> {
                        out.write(("HTTP/1.1 200 OK\r\nCache-Control: no-store\r\nConnection: close\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n\r\n").toByteArray())
                        out.flush()
                        while (running.get() && !client.isClosed) {
                            val frame = latestJpeg.get()
                            if (frame != null) {
                                out.write("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${frame.size}\r\n\r\n".toByteArray())
                                out.write(frame)
                                out.write("\r\n".toByteArray())
                                out.flush()
                            }
                            Thread.sleep(100)
                        }
                    }
                    method == "GET" && path == "/" -> {
                        val html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#000'><img src='/stream.mjpg' style='width:100vw;height:100vh;object-fit:contain'></body></html>"
                        respond(out, "200 OK", html, "text/html; charset=utf-8")
                    }
                    else -> respond(out, "404 Not Found", "Bulunamadı")
                }
            } catch (_: Exception) {
                // A disconnected receiver must not stop the capture service.
            }
        }
    }

    private fun readAsciiLine(input: BufferedInputStream, max: Int): String? {
        val bytes = ByteArrayOutputStream()
        while (bytes.size() < max) {
            val value = input.read()
            if (value < 0) return if (bytes.size() == 0) null else bytes.toString("US-ASCII").trimEnd('\r')
            if (value == '\n'.code) return bytes.toString("US-ASCII").trimEnd('\r')
            bytes.write(value)
        }
        throw IllegalArgumentException("HTTP line too long")
    }

    private fun respond(out: java.io.OutputStream, status: String, body: String, contentType: String = "text/plain; charset=utf-8") {
        val bytes = body.toByteArray(Charsets.UTF_8)
        out.write("HTTP/1.1 $status\r\nContent-Type: $contentType\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Superb Mirror ekran paylaşımı", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(this, CHANNEL_ID).setContentTitle("Superb Mirror çalışıyor")
            .setContentText("Ekran paylaşımı açık • Yerel ağ portu $PORT")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
    } else {
        @Suppress("DEPRECATION")
        Notification.Builder(this).setContentTitle("Superb Mirror çalışıyor")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
    }

    override fun onDestroy() {
        running.set(false)
        try { server?.close() } catch (_: Exception) { }
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        captureThread?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
