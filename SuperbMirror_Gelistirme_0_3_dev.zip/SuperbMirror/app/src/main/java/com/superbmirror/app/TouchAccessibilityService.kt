package com.superbmirror.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicReference

/** Receives explicit, authenticated input commands from a trusted local bridge. */
class TouchAccessibilityService : AccessibilityService() {
    companion object {
        private val instance = AtomicReference<TouchAccessibilityService?>(null)

        fun tap(x: Float, y: Float, holdMs: Long = 70L): Boolean =
            instance.get()?.dispatchTap(x, y, holdMs) ?: false

        fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 350L): Boolean =
            instance.get()?.dispatchSwipe(x1, y1, x2, y2, durationMs) ?: false
    }

    override fun onServiceConnected() { instance.set(this) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance.compareAndSet(this, null)
        super.onDestroy()
    }

    private fun screenPoint(nx: Float, ny: Float): Pair<Float, Float>? {
        if (!nx.isFinite() || !ny.isFinite() || nx !in 0f..1f || ny !in 0f..1f) return null
        val metrics = resources.displayMetrics
        return Pair(
            (nx * metrics.widthPixels).coerceIn(0f, (metrics.widthPixels - 1).toFloat()),
            (ny * metrics.heightPixels).coerceIn(0f, (metrics.heightPixels - 1).toFloat())
        )
    }

    private fun dispatchTap(nx: Float, ny: Float, holdMs: Long): Boolean {
        val (x, y) = screenPoint(nx, ny) ?: return false
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, holdMs.coerceIn(40L, 1000L))
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun dispatchSwipe(x1n: Float, y1n: Float, x2n: Float, y2n: Float, durationMs: Long): Boolean {
        val start = screenPoint(x1n, y1n) ?: return false
        val end = screenPoint(x2n, y2n) ?: return false
        val path = Path().apply {
            moveTo(start.first, start.second)
            lineTo(end.first, end.second)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(80L, 1500L))
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
