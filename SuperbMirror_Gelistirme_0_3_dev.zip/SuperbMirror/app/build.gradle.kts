plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.superbmirror.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.superbmirror.app"
        minSdk = 26
        targetSdk = 33
        versionCode = 3
        versionName = "0.3-dev"
    }
}
